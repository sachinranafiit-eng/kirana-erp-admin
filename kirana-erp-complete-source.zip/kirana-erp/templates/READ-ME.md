# Bulk import templates

Use **Products / Inventory / Customers / Suppliers → Bulk add / Templates**, or **Import data**.

1. Choose the type of records.
2. Download CSV or Excel. Replace the example row with your data. The example is not real business data.
3. Keep the exact column headings. You may leave optional fields blank. Preserve mobile numbers, state codes, SKUs, GSTINs and barcodes as text in Excel.
4. Upload the completed file (maximum 500 rows, 5 MB), review and edit the rows, then select Save.
5. If any row fails, nothing in that batch is saved. Fix it and submit again.

| Template | Required | Meaning |
| --- | --- | --- |
| Products | sku, name, unit, mrp, salePrice | New product master records; unit is an existing short code such as pkt or kg. Cost excludes GST; salePrice includes GST. |
| Stock | sku, quantity, reason | Adjusts existing products in the current store. Quantity is a positive/negative change, not the final stock balance. |
| Customers | name | New customers; openingBalance is money owed to the shop. |
| Suppliers | companyName | New suppliers; openingBalance is money the shop owes. |

Stock: use batchNumber and YYYY-MM-DD expiryDate for batches. Negative stock is rejected. An expiry requires a batch number; a known batch must retain its existing expiry. Entries with no batch change unbatched stock. Use Purchases to receive supplier invoices and update product costs.

Duplicate product SKUs, or duplicate customer/supplier mobiles or name/address pairs, are rejected. A retry of the same submitted batch will not add the stock again. These templates create new records; they do not bulk-overwrite existing customer or supplier masters.

Scanned PDFs require OCR outside the app; CSV and Excel are recommended for reliable imports.
