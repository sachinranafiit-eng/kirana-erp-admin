#!/bin/bash
set -e
cd "$(dirname "$0")"
BUNDLED_NODE="/Users/mac/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
if command -v node >/dev/null 2>&1; then NODE="$(command -v node)"; elif [ -x "$BUNDLED_NODE" ]; then NODE="$BUNDLED_NODE"; else echo 'Install Node.js 22 or later, then run npm install and npm run build.'; read -r; exit 1; fi
if [ ! -d node_modules ] || [ ! -f dist/index.html ]; then echo 'Run npm install and npm run build first (see README.md).'; read -r; exit 1; fi
printf '\nKirana ERP opens at http://127.0.0.1:4173\nKeep this window open while using the app.\n\n'
exec "$NODE" backend/src/server.js
