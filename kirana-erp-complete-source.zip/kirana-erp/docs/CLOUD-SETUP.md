# GitHub, Google Drive and online ordering

## Current delivery status

The updated app runs locally. Source is prepared for the user's repository, `https://github.com/sachinranafiit-eng/ERP`. Cloud hosting is separate: no cloud host has been provisioned.

A source-code backup is saved to the connected Google Drive account. This is not a backup of the live store database. Local records remain on the user's computer.

The live shop and ERP use the same database at `/store` and `/`. On the default local port, the former demo URL on port 4174 redirects to the live shop on 4173. The original sample database is retained as an isolated development fixture and is no longer served to customers.

## Put the source in GitHub

1. Use the existing `sachinranafiit-eng/ERP` repository. It is public: only application source and synthetic examples belong there.
2. Publish the contents of this directory. `.gitignore` excludes data, secrets and dependency folders. Never add `.env`, `data/` or live database backups to GitHub.
3. `.github/workflows/ci.yml` runs tests and builds the app on pushes and pull requests. A successful CI run does not by itself publish the app.

## Run online with Render

A ready-to-review `render.yaml` and `Dockerfile` are included. The Blueprint creates one Node web service and a private PostgreSQL 15 database in Singapore. These are paid hosting resources; review Render's displayed charges before provisioning. Nothing has been purchased or provisioned by this task.

1. Connect the repository in your Render account and create a Blueprint from `render.yaml`.
2. Render generates the staff/customer signing secrets and `SETUP_TOKEN`. Open the assigned HTTPS URL and enter the setup token from the server environment to create the first owner account. Never publish this token.
3. Keep `DB_MODE=postgres`. Production cannot use a disposable local database directory. The app and API run at the same origin; the customer app is at `/store`.
4. Enable the online store under **Online store → settings**; set the store name, delivery fee, minimum order, delivery pincodes and truthful delivery-time message.
5. Mark the desired products visible under **Online store → catalog**. Public stock excludes expired batches. Configure actual product photographs through the product visibility API's `onlineImages` field (HTTPS URLs).
6. Customer username/password registration works without SMS. SMS OTP is optional and appears only when the server has MSG91 credentials; configure and test the provider before offering that alternative. No SMS account, payment gateway, rider service or Blinkit partnership is connected.

The customer app supports search, category browsing, quantities, basket storage, server-calculated GST-inclusive totals, pickup/delivery, password sign-in (and optional SMS OTP), pay on delivery, order history and status tracking. It includes a web app manifest and an offline notice; ordering needs an internet connection. Use the browser's **Add to Home Screen / Install app** when available. This package is a web app, not an Android APK or an App Store release.

References: [Render Blueprint specification](https://render.com/docs/blueprint-spec), [Render Blueprints](https://render.com/docs/infrastructure-as-code).

## Google Drive database backups from the ERP

**Settings → Google Drive cloud backup** connects the running ERP to your own server-side Google OAuth credentials. The ChatGPT Google Drive connector does not grant the running application an OAuth token.

Set these environment variables privately on the host:

- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- `GOOGLE_REFRESH_TOKEN`
- `GOOGLE_DRIVE_FOLDER_ID`

Create the OAuth client in your Google Cloud project, enable Drive API, and authorize your Google account for offline access. Prefer the `drive.file` scope and create/select the target folder using that same OAuth application. A folder visible to the ChatGPT connector is not automatically accessible through `drive.file` to a different OAuth client. Store the resulting refresh token only in the host's secrets, never in the frontend or GitHub.

The backup button obtains a short-lived token, snapshots the database, uploads to the configured folder through Google's resumable upload protocol and records a successful upload's timestamp/link. It does not alter sharing permissions. Embedded backups are `.tar.gz`; server PostgreSQL backups are `.dump` and require the matching `pg_dump` client, provided by the Dockerfile. This implementation buffers up to 256 MB for server dumps; larger databases should use a streaming backup service. Automatic scheduled backups are not enabled.

Restore an embedded archive using `scripts/restore.js` into a new directory while the app is stopped. Restore a server dump into a separate compatible PostgreSQL database using `pg_restore --no-owner --no-acl`. Test a restoration before relying on any backup.

References: [Google Drive uploads](https://developers.google.com/workspace/drive/api/guides/manage-uploads), [Google OAuth for web servers](https://developers.google.com/identity/protocols/oauth2/web-server).

## Existing local records

Cloud provisioning starts a new PostgreSQL database. It does not migrate your existing local records. The embedded archive is a physical PGlite backup and is not a `pg_restore`-compatible dump. A checked logical data migration is required before moving a populated local store to cloud PostgreSQL. Keep the local app as the active system until that migration is completed and verified.
