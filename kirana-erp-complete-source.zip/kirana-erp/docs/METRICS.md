# Store metric definitions

The source of truth is the transactional PostgreSQL database. These definitions were selected for daily store operations using the supplied architecture and Data's KPI-design workflow. No external company data or measured business targets were supplied.

| Metric | Definition and source | Decision / limitation |
|---|---|---|
| Net sales | Completed POS invoices including GST, excluding quotes/cancellations, less returns dated in the period | Daily trading performance; return timing may make a day negative |
| Gross profit | Taxable POS sales less historical sale-item cost; reverse returned taxable revenue and cost | Pricing/margin monitoring; tax excluded; original-sale cost snapshot retained |
| Net profit | Gross profit less recorded expenses in the period | Operating result only; not statutory accounting |
| Customer dues | Opening balance + completed sales − returns − receipts/refunds | Follow up collections; shared across stores |
| Supplier payable | Opening balance + purchase invoices − returns − payments | Schedule supplier payments; shared across stores |
| Stock value | Current quantity × current weighted-average cost | Purchasing/cash planning; excludes GST; not a FIFO valuation |
| Low stock | Active product quantity in selected store ≤ reorder level | Replenishment queue; thresholds are editable per product |
| Expiry watch | Positive batch stock expiring within 30 days, including expired batches | Avoid waste; requires batch dates |

Guardrails: no negative stock, credit-limit validation, immutable stock history, transaction rollback and duplicate-submit protection. Keep net-sales and gross-profit together so revenue growth does not hide declining margins. Review stock and customer dues alongside profit to track cash tied up in the business.

No targets or percentage improvements are invented. Establish a baseline using actual store transactions before setting targets. Sample store records are synthetic and are labelled throughout the app. Online orders are managed separately and are not included in POS reporting.
