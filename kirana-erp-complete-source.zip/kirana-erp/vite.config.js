const {defineConfig}=require('vite');module.exports=defineConfig({server:{proxy:{'/api':'http://127.0.0.1:4173','/health':'http://127.0.0.1:4173'}},build:{outDir:'dist'}});
